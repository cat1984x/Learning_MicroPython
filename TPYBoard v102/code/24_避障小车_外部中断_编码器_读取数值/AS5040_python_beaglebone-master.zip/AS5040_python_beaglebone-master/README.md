# AS5040_python_beaglebone
Python code for interfacing the austrian microsystems as50xx magnetic rotary encoders.
very preliminary version
